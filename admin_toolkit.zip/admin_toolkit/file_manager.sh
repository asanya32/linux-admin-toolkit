#!/bin/bash

LOG="file_ops.log"
echo -e "\e[34mFile Manager Menu\e[0m"
echo "1. Create File/Directory"
echo "2. Rename File/Directory"
echo "3. Delete File/Directory"
echo "4. Cleanup Old Files (7+ days)"
read -p "Choose option: " opt

timestamp=$(date '+%Y-%m-%d %H:%M:%S')

case $opt in
  1)
    read -p "Enter name: " name
    mkdir -p "$name" && echo "$timestamp Created $name" >> $LOG
    ;;
  2)
    read -p "Enter old name: " old
    read -p "Enter new name: " new
    mv "$old" "$new" && echo "$timestamp Renamed $old to $new" >> $LOG
    ;;
  3)
    read -p "Enter name to delete: " del
    rm -rf "$del" && echo "$timestamp Deleted $del" >> $LOG
    ;;
  4)
    read -p "Enter directory path: " path
    find "$path" -type f -mtime +7 -delete
    echo "$timestamp Deleted files older than 7 days in $path" >> $LOG
    ;;
  *)
    echo "Invalid option"
    ;;
esac
