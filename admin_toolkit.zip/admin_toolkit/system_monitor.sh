#!/bin/bash

LOG_DIR="./logs"
DATE=$(date +%Y%m%d)
LOG_FILE="$LOG_DIR/monitor_${DATE}.log"
mkdir -p "$LOG_DIR"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_action() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

write_header() {
    echo "=== System Monitoring Report ===" > "$LOG_FILE"
    echo "Date: $(date)" >> "$LOG_FILE"
    echo "===============================" >> "$LOG_FILE"
}

monitor_cpu_memory() {
    echo -e "${YELLOW}Gathering CPU and memory stats...${NC}"
    echo -e "\n--- CPU & Memory (vmstat) ---" >> "$LOG_FILE"
    vmstat 1 5 >> "$LOG_FILE"

    echo -e "\n--- RAM (free -h) ---" >> "$LOG_FILE"
    free -h >> "$LOG_FILE"

    echo -e "\n--- Uptime ---" >> "$LOG_FILE"
    uptime >> "$LOG_FILE"

    echo -e "\n--- CPU Summary ---" >> "$LOG_FILE"
    top -bn1 | grep "Cpu(s)" >> "$LOG_FILE"

    echo -e "\n--- Load Average ---" >> "$LOG_FILE"
    cat /proc/loadavg >> "$LOG_FILE"

    echo -e "${GREEN}CPU and memory data logged.${NC}"
    log_action "CPU and memory stats collected"
}

monitor_disk() {
    echo -e "${YELLOW}Checking disk usage...${NC}"
    echo -e "\n--- Disk Usage (df -h) ---" >> "$LOG_FILE"
    df -h >> "$LOG_FILE"
    log_action "Disk usage logged"
}

monitor_processes() {
    echo -e "${YELLOW}Saving top 10 processes by CPU...${NC}"
    echo -e "\n--- Top 10 CPU Consuming Processes ---" >> "$LOG_FILE"
    ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 11 >> "$LOG_FILE"
    log_action "Top processes logged"
}

main() {
    write_header
    monitor_cpu_memory
    monitor_disk
    monitor_processes

    echo -e "${GREEN}System monitoring complete. Log saved to:${NC} ${YELLOW}$LOG_FILE${NC}"
}

main
