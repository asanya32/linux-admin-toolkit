#!/bin/bash

LOG="packages.log"
PKG_FILE="packages.conf"
timestamp=$(date '+%Y-%m-%d %H:%M:%S')

echo -e "\e[36m==== Software Installer & Updater ====\e[0m"

# Check if package file exists
if [[ ! -f $PKG_FILE ]]; then
  echo "$timestamp ERROR: Package config file $PKG_FILE not found!" | tee -a $LOG
  exit 1
fi

# Update system
echo "$timestamp Starting system update..." | tee -a $LOG
sudo apt update && sudo apt upgrade -y >> $LOG 2>&1

# Install packages
while IFS= read -r pkg; do
  if [[ ! -z "$pkg" ]]; then
    echo "$timestamp Installing $pkg..." | tee -a $LOG
    sudo apt install -y "$pkg" >> $LOG 2>&1
    echo "$timestamp $pkg installation done." >> $LOG
  fi
done < "$PKG_FILE"

echo "$timestamp All packages processed." | tee -a $LOG
