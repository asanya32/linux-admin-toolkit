#!/bin/bash

LOG_DIR="./logs"
LOG_FILE="$LOG_DIR/network.log"
mkdir -p "$LOG_DIR"

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_action() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

ping_test() {
    read -p "Enter host to ping (e.g., google.com): " host
    echo -e "${YELLOW}Pinging $host...${NC}"

    output=$(ping -c 4 "$host" 2>&1)

    if echo "$output" | grep -q "0 received"; then
        echo -e "${RED}Ping failed: No packets received.${NC}"
        log_action "Ping to $host - FAILED (0 packets received)"
        return
    fi

    echo "$output" >> "$LOG_FILE"
    avg_latency=$(echo "$output" | grep 'rtt' | awk -F '/' '{print $5}')

    if [[ $avg_latency ]]; then
        log_line="Ping to $host - Avg latency: ${avg_latency}ms"
        if (( $(echo "$avg_latency > 100" | bc -l) )); then
            echo -e "${RED}⚠  High latency: ${avg_latency}ms${NC}"
            log_action "$log_line - WARNING: Slow connection"
        else
            echo -e "${GREEN}✅ Latency OK: ${avg_latency}ms${NC}"
            log_action "$log_line - SUCCESS"
        fi
    else
        echo -e "${RED}Could not parse latency.${NC}"
        log_action "Ping to $host - FAILED (no latency info)"
    fi
}

traceroute_test() {
    read -p "Enter host for traceroute: " host
    echo -e "${YELLOW}Tracing route to $host...${NC}"

    if ! command -v traceroute &> /dev/null; then
        echo -e "${RED}traceroute command not found. Try: sudo apt install traceroute${NC}"
        log_action "Traceroute to $host - FAILED (command not found)"
        return
    fi

    traceroute "$host" | tee -a "$LOG_FILE"
    log_action "Traceroute to $host - SUCCESS"
}

curl_test() {
    read -p "Enter URL to curl (e.g., https://openai.com): " url
    echo -e "${YELLOW}Sending curl request to $url...${NC}"
    response=$(curl -I --max-time 10 "$url" 2>&1)

    echo "$response" >> "$LOG_FILE"
    if echo "$response" | grep -q "HTTP"; then
        echo -e "${GREEN}✅ Curl test succeeded.${NC}"
        log_action "Curl to $url - SUCCESS"
    else
        echo -e "${RED}Curl failed or timed out.${NC}"
        log_action "Curl to $url - FAILED"
    fi
}

dns_lookup() {
    read -p "Enter domain to lookup (e.g., openai.com): " domain
    echo -e "${YELLOW}Performing DNS lookup...${NC}"
    
    if command -v dig &> /dev/null; then
        dig "$domain" | tee -a "$LOG_FILE"
    elif command -v nslookup &> /dev/null; then
        nslookup "$domain" | tee -a "$LOG_FILE"
    else
        echo -e "${RED}Neither dig nor nslookup found. Please install one.${NC}"
        log_action "DNS lookup for $domain - FAILED (no tool)"
        return
    fi

    echo -e "${GREEN}✅ DNS lookup completed.${NC}"
    log_action "DNS lookup for $domain - SUCCESS"
}

show_menu() {
    echo -e "\n${YELLOW}--- Network Diagnostic Tool ---${NC}"
    echo "1. Ping Test"
    echo "2. Traceroute"
    echo "3. Curl Test"
    echo "4. DNS Lookup"
    echo "5. Exit"
}

main() {
    while true; do
        show_menu
        read -p "Select an option [1-5]: " choice
        case $choice in
            1) ping_test ;;
            2) traceroute_test ;;
            3) curl_test ;;
            4) dns_lookup ;;
            5) echo -e "${GREEN}Exiting Network Tool.${NC}"; break ;;
            *) echo -e "${RED}Invalid choice. Try again.${NC}" ;;
        esac
    done
}

main
