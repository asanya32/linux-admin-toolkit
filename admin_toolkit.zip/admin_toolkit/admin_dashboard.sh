#!/bin/bash

# Color Codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

TOOLKIT_DIR="$HOME/admin_toolkit"
LOG_DIR="$TOOLKIT_DIR/logs"
mkdir -p "$LOG_DIR"

# Header
echo -e "${YELLOW}\n=== Linux System Admin Toolkit ===${NC}"

while true; do
  echo -e "\n${YELLOW}Main Menu:${NC}"
  echo "1. File Manager"
  echo "2. User Manager"
  echo "3. System Monitor"
  echo "4. Network Diagnostic Tool"
  echo "5. View Logs"
  echo "6. Exit"

  read -p "Choose an option [1-6]: " opt

  case $opt in
    1)
      bash "$TOOLKIT_DIR/file_manager.sh"
      ;;
    2)
      bash "$TOOLKIT_DIR/user_manager.sh"
      ;;
    3)
      bash "$TOOLKIT_DIR/system_monitor.sh"
      ;;
    4)
      bash "$TOOLKIT_DIR/network_tool.sh"
      ;;
    5)
      echo -e "${GREEN}Available Logs:${NC}"
      ls -1 "$LOG_DIR"
      read -p "Enter log filename to view: " logfile
      if [[ -f "$LOG_DIR/$logfile" ]]; then
        less "$LOG_DIR/$logfile"
      else
        echo -e "${RED}Log not found.${NC}"
      fi
      ;;
    6)
      echo -e "${GREEN}Exiting Toolkit. Goodbye!${NC}"
      exit 0
      ;;
    *)
      echo -e "${RED}Invalid choice. Try again.${NC}"
      ;;
  esac
done
