# 🛠️ Linux System Admin Toolkit

A project designed to automate and simplify routine Linux system administration tasks using Bash scripts.

---

## 📁 Toolkit Overview

| Script                | Purpose                                 |
|-----------------------|-----------------------------------------|
| `admin_dashboard.sh`  | Central menu for all toolkit features   |
| `file_manager.sh`     | Manage files/directories and cleanup    |
| `user_manager.sh`     | Manage users, groups, and permissions   |
| `system_monitor.sh`   | Monitor CPU, memory, disk, top processes|
| `network_tool.sh`     | Run ping, traceroute, DNS check, curl   |
| `package_installer.sh`| Install/update system packages          |

---

## 🚀 How to Run

Make scripts executable:
```bash
chmod +x *.sh
