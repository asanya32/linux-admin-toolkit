#!/bin/bash

LOG="user_audit.log"
echo -e "\e[32mUser & Permission Manager\e[0m"
echo "1. Create user and set password"
echo "2. Create group"
echo "3. Add user to group"
echo "4. Set permissions for a directory"
echo "5. Generate permissions report for /home"
read -p "Choose option: " opt

timestamp=$(date '+%Y-%m-%d %H:%M:%S')

case $opt in
  1)
    read -p "Enter username: " user
    sudo useradd "$user" && echo "$timestamp Created user $user" >> $LOG
    sudo passwd "$user"
    ;;
  2)
    read -p "Enter group name: " group
    sudo groupadd "$group" && echo "$timestamp Created group $group" >> $LOG
    ;;
  3)
    read -p "Enter username: " user
    read -p "Enter group name: " group
    sudo usermod -aG "$group" "$user" && echo "$timestamp Added $user to $group" >> $LOG
    ;;
  4)
    read -p "Enter directory: " dir
    read -p "Enter permissions (e.g., 755): " perms
    read -p "Enter owner (user:group): " owner
    sudo chmod "$perms" "$dir"
    sudo chown "$owner" "$dir"
    echo "$timestamp Set $perms and owner $owner on $dir" >> $LOG
    ;;
  5)
    echo "$timestamp Permission Report:" >> $LOG
    ls -ld /home/* >> $LOG
    echo "Report written to $LOG"
    ;;
  *)
    echo "Invalid option"
    ;;
esac
